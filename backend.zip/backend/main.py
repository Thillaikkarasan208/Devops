import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()

app = FastAPI(title="Collaborate API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5175",
        "http://127.0.0.1:5175",
        "http://localhost:5176",
        "http://127.0.0.1:5176",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

GITHUB_API_BASE = "https://api.github.com"


@app.get("/api/health")
def health_check() -> dict:
    return {"status": "ok"}


@app.post("/api/login")
def login(username: str, password: str) -> dict:
    # Fixed credentials requested for demo login.
    if username != "admin" or password != "admin1234":
        raise HTTPException(status_code=401, detail="Invalid username or password.")
    return {"message": f"Welcome {username}", "authenticated": True}


@app.get("/api/github/repos")
def get_github_repositories(
    username: str = Query(..., min_length=1),
    github_token: Optional[str] = Header(default=None, convert_underscores=False),
) -> dict:
    token = github_token or os.getenv("GITHUB_TOKEN")
    if not token:
        raise HTTPException(
            status_code=401,
            detail="GitHub token missing. Send `github_token` header or set GITHUB_TOKEN.",
        )

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    response = requests.get(
        f"{GITHUB_API_BASE}/users/{username}/repos",
        headers=headers,
        params={"sort": "updated", "per_page": 100},
        timeout=20,
    )
    if response.status_code == 401:
        raise HTTPException(status_code=401, detail="Invalid GitHub token.")
    if response.status_code == 404:
        raise HTTPException(status_code=404, detail="GitHub user not found.")
    if response.status_code != 200:
        raise HTTPException(status_code=response.status_code, detail="GitHub API request failed.")

    repos = response.json()
    projects = [
        {
            "id": repo["id"],
            "name": repo["name"],
            "full_name": repo["full_name"],
            "private": repo["private"],
            "html_url": repo["html_url"],
        }
        for repo in repos
    ]
    return {"projects": projects}


CONFIG_DIR = Path(__file__).parent / "configs"


class MavenConfig(BaseModel):
    projectName: str
    repositoryUrl: str
    branch: str = "main"
    pomPath: str = "pom.xml"
    mavenHome: Optional[str] = None
    mavenGoals: str = "clean package"
    javaVersion: str = "17"
    settingsXmlPath: Optional[str] = None
    outputDir: str = "target"
    skipTests: bool = False


def _resolve_mvn(maven_home: Optional[str]) -> str:
    if maven_home:
        candidate = Path(maven_home) / "bin" / ("mvn.cmd" if os.name == "nt" else "mvn")
        if candidate.exists():
            return str(candidate)
        raise HTTPException(status_code=400, detail=f"mvn not found under {maven_home}.")
    found = shutil.which("mvn") or shutil.which("mvn.cmd")
    if not found:
        raise HTTPException(
            status_code=400,
            detail="Maven not found on PATH. Install Maven or set Maven home.",
        )
    return found


@app.get("/api/maven/test")
def maven_test(maven_home: Optional[str] = Query(default=None)) -> dict:
    mvn = _resolve_mvn(maven_home)
    try:
        result = subprocess.run(
            [mvn, "-v"], capture_output=True, text=True, timeout=20
        )
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="Maven took too long to respond.") from exc
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Failed to run Maven: {exc}") from exc
    if result.returncode != 0:
        raise HTTPException(status_code=500, detail=result.stderr or "mvn -v failed.")
    return {"version": result.stdout.strip().splitlines()[0] if result.stdout else "Maven OK"}


@app.post("/api/maven/configure")
def maven_configure(config: MavenConfig) -> dict:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    target_file = CONFIG_DIR / f"{config.projectName}.json"
    target_file.write_text(json.dumps(config.model_dump(), indent=2), encoding="utf-8")

    args = ["mvn", "-f", config.pomPath]
    if config.settingsXmlPath:
        args += ["-s", config.settingsXmlPath]
    if config.skipTests:
        args.append("-DskipTests")
    args += config.mavenGoals.split()
    return {
        "saved": True,
        "configPath": str(target_file),
        "command": " ".join(args),
    }
