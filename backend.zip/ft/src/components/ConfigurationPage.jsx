import { useState } from "react";
import { Link } from "react-router-dom";
import ThemeToggle from "./ThemeToggle";

const API_BASE = "http://127.0.0.1:8000";

const initialForm = {
  projectName: "",
  repositoryUrl: "",
  branch: "main",
  pomPath: "pom.xml",
  mavenHome: "",
  mavenGoals: "clean package",
  javaVersion: "17",
  settingsXmlPath: "",
  outputDir: "target",
  skipTests: false,
};

function ConfigurationPage() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState(null);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);

  const onChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  };

  const handleTestConnection = async () => {
    setStatus(null);
    setTesting(true);
    try {
      const params = new URLSearchParams();
      if (form.mavenHome) params.set("maven_home", form.mavenHome);
      const response = await fetch(`${API_BASE}/api/maven/test?${params.toString()}`);
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || "Maven not reachable.");
      }
      setStatus({ kind: "success", message: data.version || "Maven reachable." });
    } catch (error) {
      setStatus({ kind: "error", message: error.message });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = async (event) => {
    event.preventDefault();
    setStatus(null);
    setSaving(true);
    try {
      const response = await fetch(`${API_BASE}/api/maven/configure`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || "Could not save configuration.");
      }
      setStatus({
        kind: "success",
        message: `Saved. Run command: ${data.command}`,
      });
    } catch (error) {
      setStatus({ kind: "error", message: error.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <main className="collaborate-layout">
      <aside className="left-nav">
        <div className="left-nav-scroll">
          <h2 className="brand-title">codev</h2>
          <nav className="nav-sheet">
            <p className="nav-item">HOME</p>
            <p className="nav-item">DEV</p>

            <div className="nav-group">
              <Link className="nav-item nav-link" to="/collaborate">
                COLLABORATE
              </Link>
              <p className="nav-sub-title">LIVE TRACKING</p>
              <p className="nav-sub-item">Work Items</p>
            </div>

            <div className="nav-group">
              <p className="nav-item active">CI/CD</p>
              <p className="nav-sub-item">CI/CD</p>
              <p className="nav-sub-item">Analysis</p>
              <p className="nav-sub-item">Validation</p>
              <Link className="nav-sub-item nav-link" to="/builds">
                Builds
              </Link>
              <p className="nav-sub-item">Release Candidates</p>
              <p className="nav-sub-item">Releases</p>
              <p className="nav-sub-item active-sub">Configuration</p>
            </div>
          </nav>
        </div>
        <ThemeToggle />
      </aside>

      <section className="collaborate-board">
        <div className="board-top-strip">/</div>
        <header className="board-header">
          <h1>Platform Configuration</h1>
        </header>

        <article className="builds-content">
          <section className="config-section">
            <h3 className="config-section-title">Maven</h3>
            <p>
              Connect your Maven build so codev can compile your Java project and produce
              <code> .jar </code> artifacts on every build run.
            </p>

            <form className="maven-form" onSubmit={handleSave}>
            <div className="form-grid">
              <label>
                <span>Project name</span>
                <input
                  name="projectName"
                  value={form.projectName}
                  onChange={onChange}
                  placeholder="my-service"
                  required
                />
              </label>

              <label>
                <span>Repository URL</span>
                <input
                  name="repositoryUrl"
                  value={form.repositoryUrl}
                  onChange={onChange}
                  placeholder="https://github.com/org/repo.git"
                  required
                />
              </label>

              <label>
                <span>Branch</span>
                <input name="branch" value={form.branch} onChange={onChange} />
              </label>

              <label>
                <span>POM file path</span>
                <input name="pomPath" value={form.pomPath} onChange={onChange} />
              </label>

              <label>
                <span>Maven home (optional)</span>
                <input
                  name="mavenHome"
                  value={form.mavenHome}
                  onChange={onChange}
                  placeholder="C:\\apache-maven-3.9.6"
                />
              </label>

              <label>
                <span>Maven goals</span>
                <input name="mavenGoals" value={form.mavenGoals} onChange={onChange} />
              </label>

              <label>
                <span>Java version</span>
                <select name="javaVersion" value={form.javaVersion} onChange={onChange}>
                  <option value="8">8</option>
                  <option value="11">11</option>
                  <option value="17">17</option>
                  <option value="21">21</option>
                </select>
              </label>

              <label>
                <span>settings.xml path (optional)</span>
                <input
                  name="settingsXmlPath"
                  value={form.settingsXmlPath}
                  onChange={onChange}
                  placeholder="~/.m2/settings.xml"
                />
              </label>

              <label>
                <span>Output directory</span>
                <input name="outputDir" value={form.outputDir} onChange={onChange} />
              </label>

              <label className="checkbox-label">
                <input
                  type="checkbox"
                  name="skipTests"
                  checked={form.skipTests}
                  onChange={onChange}
                />
                <span>Skip tests (-DskipTests)</span>
              </label>
            </div>

            <div className="form-actions">
              <button type="button" onClick={handleTestConnection} disabled={testing}>
                {testing ? "Testing..." : "Test connection"}
              </button>
              <button type="submit" className="primary" disabled={saving}>
                {saving ? "Saving..." : "Save configuration"}
              </button>
            </div>

            {status && (
              <p className={`status-text ${status.kind}`}>{status.message}</p>
            )}
            </form>
          </section>
        </article>
      </section>
    </main>
  );
}

export default ConfigurationPage;
